import Gallery from "../components/Gallery"

export default function Home() {
  return (
    <> 
    <h1>Bienvenido a nuestra App de Escapadas</h1>
    <Gallery></Gallery>

    </>
  )
}
